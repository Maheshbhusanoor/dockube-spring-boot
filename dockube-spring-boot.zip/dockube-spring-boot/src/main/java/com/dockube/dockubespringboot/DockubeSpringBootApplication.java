package com.dockube.dockubespringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DockubeSpringBootApplication {
	public static void main(String[] args) {
		SpringApplication.run(DockubeSpringBootApplication.class, args);
	}
	@GetMapping("ping")
	public String getData(){
		return "Pong";
	}

}
